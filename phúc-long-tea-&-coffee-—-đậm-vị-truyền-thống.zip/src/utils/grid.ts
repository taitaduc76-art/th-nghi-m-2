/**
 * Grid Layout Algorithm
 * For each row r, compute primary column: a = (r * 2 + (r % 2)) % cols
 * Place one image at column a
 * Every 3rd row (r % 3 === 0), place a second image at b = (a + 2) % cols (or (a + 1) % cols if same as a)
 * Empty cells get -1 (rendered as empty spacer divs)
 */
export function buildLayout(count: number, cols: number): number[][] {
  const rows: number[][] = [];
  let imgIndex = 0;
  let r = 0;

  while (imgIndex < count) {
    const row: number[] = new Array(cols).fill(-1);
    const a = (r * 2 + (r % 2)) % cols;
    row[a] = imgIndex++;

    if (imgIndex < count && r % 3 === 0) {
      let b = (a + 2) % cols;
      if (b === a) {
        b = (a + 1) % cols;
      }
      row[b] = imgIndex++;
    }

    rows.push(row);
    r++;
  }

  return rows;
}
