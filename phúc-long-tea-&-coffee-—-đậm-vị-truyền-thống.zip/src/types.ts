export type Breakpoint = 'mobile' | 'tablet' | 'desktop';

export interface LayoutCell {
  imageIndex: number; // -1 for empty spacer cell
  row: number;
  col: number;
}

export type DrinkCategory = 'all' | 'tea' | 'milktea' | 'coffee' | 'iceblended';

export interface DrinkProduct {
  id: string;
  name: string;
  englishName: string;
  category: DrinkCategory;
  price: number;
  formattedPrice: string;
  image: string;
  badge?: string;
  description: string;
  tasteNotes: string[];
  ingredients: string;
  origin: string;
  calories?: string;
  popular?: boolean;
}

export interface CartItem {
  drink: DrinkProduct;
  quantity: number;
  sugar: string;
  ice: string;
  topping: string;
}
