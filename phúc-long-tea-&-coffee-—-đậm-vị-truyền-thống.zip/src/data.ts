import type { DrinkProduct } from './types';

import phuclongTraDao from './assets/images/phuclong_tra_dao_1788538567096.jpg';
import phuclongTraSua from './assets/images/phuclong_tra_sua_1788538583123.jpg';
import phuclongTraVaiSen from './assets/images/phuclong_tra_vai_sen_1788538600539.jpg';
import phuclongSnowIce from './assets/images/phuclong_snow_ice_1788538621978.jpg';
import phuclongPhinCoffee from './assets/images/phuclong_phin_coffee_1788538641911.jpg';
import phuclongMatchaIce from './assets/images/phuclong_matcha_ice_1788538666342.jpg';
import phuclongTraThaoMoc from './assets/images/phuclong_tra_thao_moc_1788538684379.jpg';
import phuclongTeaHills from './assets/images/phuclong_tea_hills_1788538699068.jpg';
import phuclongHeritageBanner from './assets/images/phuclong_heritage_banner_1788539237056.jpg';
import phuclongTraNhanSen from './assets/images/phuclong_tra_nhan_sen_1788539518757.jpg';
import phuclongTraLaiSua from './assets/images/phuclong_tra_lai_sua_1788539534623.jpg';
import phuclongTerracedTeaHills from './assets/images/phuclong_terraced_tea_hills_1788539708426.jpg';
import phuclongMeadowHills from './assets/images/phuclong_meadow_hills_1788539731120.jpg';
import phuclongKiteHillsOutro from './assets/images/phuclong_kite_hills_outro_1788540221212.jpg';

export const HERO_BACKGROUND = phuclongHeritageBanner;
export const HERITAGE_BANNER = phuclongHeritageBanner;
export const TEA_HILLS_BACKGROUND = phuclongTeaHills;
export const TERRACED_TEA_HILLS_BACKGROUND = phuclongTerracedTeaHills;
export const MEADOW_HILLS_BACKGROUND = phuclongMeadowHills;
export const OUTRO_KITE_BACKGROUND = phuclongKiteHillsOutro;

export const VIDEO_LEFT =
  'https://d8j0ntlcm91z4.cloudfront.net/user_39ca84eAE1ODL9hbR5VhoEj8tBf/hf_20260625_154433_532a85d3-dabf-4265-b8bd-19ac6af31842.mp4';

export const VIDEO_RIGHT =
  'https://d8j0ntlcm91z4.cloudfront.net/user_39ca84eAE1ODL9hbR5VhoEj8tBf/hf_20260625_154401_a664f076-b971-4557-8728-40ef9ea4c49b.mp4';

export const PHUCLONG_DRINKS: DrinkProduct[] = [
  {
    id: 'tra-nhan-sen-hoi-an',
    name: 'Trà Nhãn Sen Hội An',
    englishName: 'Hoi An Lotus Longan Iced Tea',
    category: 'tea',
    price: 68000,
    formattedPrice: '68.000₫',
    image: phuclongTraNhanSen,
    badge: 'XUÔI DÒNG HỘI AN',
    description:
      'Nhật ký hè đậm vị: xuôi dòng mộng mơ Hội An cùng Trà Nhãn Sen với búp trà vàng sóng sánh thanh mát, những quả nhãn lồng giòn ngọt bọc trọn hạt sen bùi béo và lát chanh tươi giải nhiệt tuyệt đỉnh.',
    tasteNotes: ['Trà vàng thanh mát mùa hè', 'Nhãn lồng giòn ngọt bọc hạt sen', 'Lát chanh tươi sảng khoái'],
    ingredients: 'Cốt trà thơm Phúc Long, Nhãn lồng bọc hạt sen tươi, Nước đường phèn, Chanh tươi, Đá viên',
    origin: 'Phố cổ Hội An & Hạt sen Đồng Tháp Mười',
    calories: '155 kcal',
    popular: true,
  },
  {
    id: 'tra-lai-sua-thach-dua',
    name: 'Trà Lài Sữa Thạch Dừa Non',
    englishName: 'Jasmine Milk Tea with Tender Coconut Jelly',
    category: 'milktea',
    price: 62000,
    formattedPrice: '62.000₫',
    image: phuclongTraLaiSua,
    badge: 'MÓN MỚI RA MẮT',
    description:
      'Hương thơm ngát quyến rũ từ búp trà ướp hoa lài (hoa nhài) thiên nhiên quyện cùng chất sữa béo thanh tao độc quyền Phúc Long, kết hợp topping thạch dừa non dẻo quánh thanh ngọt tan trên đầu lưỡi.',
    tasteNotes: ['Hương hoa lài thơm ngát quyến rũ', 'Chất sữa béo thanh dịu', 'Topping thạch dừa non mềm dẻo'],
    ingredients: 'Trà xanh ướp hoa lài tươi, Sữa tươi thanh trùng, Thạch dừa non Bến Tre tươi xắt miếng, Lá dứa thơm',
    origin: 'Vườn trà Bảo Lộc & Xứ dừa Bến Tre',
    calories: '240 kcal',
    popular: true,
  },
  {
    id: 'tra-dao-cam-sa',
    name: 'Trà Đào Cam Sả',
    englishName: 'Signature Peach Orange Lemongrass Tea',
    category: 'tea',
    price: 60000,
    formattedPrice: '60.000₫',
    image: phuclongTraDao,
    badge: 'BEST SELLER',
    description:
      'Vị đậm đà từ cốt trà đen ủ lạnh truyền thống Phúc Long kết hợp hài hòa với những lát đào tươi giòn mọng, cam vàng ngọt thanh và hương sả nồng nàn thư thái.',
    tasteNotes: ['Đậm vị trà đen ủ lạnh', 'Thịt đào miếng giòn mọng', 'Hương sả cam thư thái'],
    ingredients: 'Cốt trà đen Phúc Long, Đào ngâm giòn, Cam sành tươi, Sả đập dập, Nước đường phèn',
    origin: 'Đồi trà Bảo Lộc (Lâm Đồng) & Cam miền Tây',
    calories: '145 kcal',
    popular: true,
  },
  {
    id: 'tra-vai-sen',
    name: 'Trà Vải Sen Bách Diệp',
    englishName: 'Lotus Lychee Herbal Tea',
    category: 'tea',
    price: 65000,
    formattedPrice: '65.000₫',
    image: phuclongTraVaiSen,
    badge: 'SIGNATURE',
    description:
      'Sự hòa quyện quý phái giữa búp trà ướp hương hoa sen Bách Diệp thanh tao và vị ngọt lịm mọng nước của những trái vải thiều chín căng tròn, thanh nhiệt tuyệt đối.',
    tasteNotes: ['Hương sen Bách Diệp quý phái', 'Trái vải thiều mọng nước', 'Hậu vị ngọt thanh tao'],
    ingredients: 'Trà ướp sen cổ truyền, Trái vải thiều tuyển chọn, Nước cốt quả ngọt, Đá viên sạch',
    origin: 'Hương sen Đồng Tháp & Trà đồi Lâm Viên',
    calories: '135 kcal',
    popular: true,
  },
  {
    id: 'tra-sua-phuc-long',
    name: 'Trà Sữa Phúc Long',
    englishName: 'Phuc Long Heritage Milk Tea',
    category: 'milktea',
    price: 55000,
    formattedPrice: '55.000₫',
    image: phuclongTraSua,
    badge: 'HUYỀN THOẠI 1968',
    description:
      'Thức uống biểu tượng làm nên tên tuổi Phúc Long hơn nửa thế kỷ: cốt trà đen đậm đặc nguyên bản kết hợp cùng sữa tươi béo ngậy, vị trà chát nhẹ đặc trưng với hậu vị ngọt bùi khó quên.',
    tasteNotes: ['Đậm chát nguyên bản', 'Béo ngậy thơm lừng', 'Hậu vị ngọt sâu kéo dài'],
    ingredients: 'Trà đen thượng hạng ủ đậm, Sữa tươi thanh trùng, Sữa đặc hảo hạng',
    origin: 'Nông trường trà Bảo Lộc - 1968',
    calories: '280 kcal',
    popular: true,
  },
  {
    id: 'tra-tuyet-da-xay',
    name: 'Ô Long Tuyết Tuyệt Đỉnh',
    englishName: 'Snow Frost Oolong Tea Float',
    category: 'iceblended',
    price: 70000,
    formattedPrice: '70.000₫',
    image: phuclongSnowIce,
    badge: 'MÓN MỚI',
    description:
      'Lớp kem tuyết mềm mịn mát lạnh bồng bềnh phủ trên nền trà Ô Long hảo hạng ủ lạnh, mang lại cảm giác tan chảy tức thì trên đầu lưỡi cùng hương thơm thanh khiết mộc mạc.',
    tasteNotes: ['Kem tuyết mịn màng bồng bềnh', 'Hương Ô Long cao nguyên', 'Mát lạnh giải nhiệt'],
    ingredients: 'Trà Ô Long đặc sản, Kem tuyết đánh bông thủ công, Sữa tươi tiệt trùng, Đá tuyết xay',
    origin: 'Cao nguyên Lâm Viên 1200m',
    calories: '210 kcal',
    popular: true,
  },
  {
    id: 'ca-phe-phin-sua-da',
    name: 'Cà Phê Phin Sữa Đá',
    englishName: 'Traditional Vietnamese Phin Coffee',
    category: 'coffee',
    price: 45000,
    formattedPrice: '45.000₫',
    image: phuclongPhinCoffee,
    badge: 'ĐẬM BẢN SẮC',
    description:
      'Chắt lọc từng giọt cà phê Robusta & Arabica nguyên chất nhỏ giọt qua phin nhôm truyền thống, quyện cùng dòng sữa đặc ngọt thơm béo bùi, đánh thức mọi giác quan tỉnh táo.',
    tasteNotes: ['Robusta đậm đà vị khói', 'Arabica chua thanh quyến rũ', 'Sữa đặc ngọt ngào béo mịn'],
    ingredients: 'Hạt cà phê rang mộc Phúc Long xay thô, Sữa đặc có đường, Đá viên tinh khiết',
    origin: 'Vùng thổ nhưỡng đỏ Buôn Ma Thuột & Cầu Đất',
    calories: '190 kcal',
    popular: true,
  },
  {
    id: 'matcha-da-xay-cream',
    name: 'Trà Xanh Đá Xay Whipping Cream',
    englishName: 'Matcha Green Tea Ice Blended',
    category: 'iceblended',
    price: 65000,
    formattedPrice: '65.000₫',
    image: phuclongMatchaIce,
    badge: 'YÊU THÍCH',
    description:
      'Búp trà xanh non tươi tuyển chọn xay nhuyễn mịn cùng sữa tươi và đá tuyết, phủ trên cùng lớp whipping cream béo ngậy rắc bột matcha nguyên chất ngào ngạt hương thơm.',
    tasteNotes: ['Bột matcha nguyên chất đậm hương', 'Whipping cream mịn màng béo ngậy', 'Vị ngọt thanh nhẹ'],
    ingredients: 'Bột búp trà xanh non Phúc Long, Sữa tươi, Whipping cream béo, Syrup đường mía',
    origin: 'Vườn trà xanh hữu cơ Bảo Lộc',
    calories: '260 kcal',
  },
  {
    id: 'tra-thao-moc-cam-dua',
    name: 'Trà Thảo Mộc Cam Dừa Hạt Chia',
    englishName: 'Herbal Orange Coconut Chia Tea',
    category: 'tea',
    price: 60000,
    formattedPrice: '60.000₫',
    image: phuclongTraThaoMoc,
    badge: 'HEALTHY FRESH',
    description:
      'Sự kết hợp thanh lọc cơ thể từ trà thảo mộc thơm lành, thạch dừa giòn sần sật mát rượi, từng lát cam vàng ươm mọng nước và siêu hạt chia bổ dưỡng dồi dào năng lượng.',
    tasteNotes: ['Cam vàng tươi mọng nước', 'Thạch dừa giòn sần sật', 'Hạt chia thanh lọc cơ thể'],
    ingredients: 'Trà thảo mộc thanh nhiệt, Thạch dừa Bến Tre tươi, Lát cam vàng, Hạt chia Organic',
    origin: 'Thảo mộc cao nguyên & Trái cây miền nhiệt đới',
    calories: '115 kcal',
  },
  {
    id: 'doi-tra-bao-loc',
    name: 'Di Sản Đồi Trà Bảo Lộc 1968',
    englishName: 'Bao Loc Heritage Tea Hills Collection',
    category: 'tea',
    price: 70000,
    formattedPrice: '70.000₫',
    image: phuclongTeaHills,
    badge: 'DI SẢN TRÀ VIỆT',
    description:
      'Bảo Lộc - mảnh đất trù phú với độ cao hơn 1.000m quanh năm sương mây bao phủ, nơi khởi nguồn của những búp trà xanh trứ danh làm nên linh hồn của thương hiệu Phúc Long từ năm 1968.',
    tasteNotes: ['Hương sương sớm cao nguyên', 'Búp trà non 1 tôm 2 lá', 'Đậm đà phong vị Việt'],
    ingredients: 'Tuyển chọn 100% búp trà non tươi thu hoạch thủ công vào sáng sớm',
    origin: 'Cao nguyên Bảo Lộc, Lâm Đồng (Since 1968)',
    calories: '0 kcal',
    popular: true,
  },
];

export const GALLERY_IMAGES = PHUCLONG_DRINKS.map((d) => d.image);

export const RANDOM_SYMBOLS = ['🍃', '🍵', '1968', '✨', '☕', '🌿'];

export const CAPTION_TEXT =
  'TÔN VINH DI SẢN — GHI DẤU THỜI ĐẠI. KHỞI NGUỒN TỪ CAO NGUYÊN BẢO LỘC NĂM 1968, CHẮT LỌC TINH HOA TỪNG BÚP TRÀ NON VÀ HẠT CÀ PHÊ THƯỢNG HẠNG VÌ VỊ ĐẬM ĐÀ NGUYÊN BẢN VIỆT NAM.';
