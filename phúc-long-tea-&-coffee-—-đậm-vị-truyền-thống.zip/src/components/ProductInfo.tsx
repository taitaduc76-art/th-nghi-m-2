import { motion } from 'motion/react';

interface ProductInfoProps {
  currentSymbol?: string;
  selectedDrinkName?: string;
  selectedDrinkPrice?: string;
}

export function ProductInfo({
  currentSymbol = '🍃',
  selectedDrinkName = 'TRÀ ĐÀO CAM SẢ',
  selectedDrinkPrice = '60.000₫',
}: ProductInfoProps) {
  return (
    <motion.div
      id="outro-info"
      data-outro-offset="166"
      className="fixed pointer-events-none z-20 flex flex-col items-center lg:items-start select-none text-white left-0 right-0 bottom-[48px] lg:left-auto lg:right-8 lg:bottom-20 lg:w-[360px] drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{
        duration: 0.6,
        ease: [0.25, 0.1, 0.25, 1],
        delay: 0.45,
      }}
    >
      {/* Top block */}
      <div className="flex flex-col items-start w-[280px] lg:w-full mb-3 lg:mb-6">
        {/* Circle icon badge with changing symbol */}
        <div className="flex items-center gap-2 mb-2">
          <div className="relative flex items-center justify-center w-7 h-7 lg:w-8 lg:h-8">
            <svg
              viewBox="0 0 40 40"
              className="absolute inset-0 w-full h-full"
              fill="none"
              stroke="white"
              strokeWidth="2.5"
              xmlns="http://www.w3.org/2000/svg"
            >
              <circle cx="20" cy="20" r="18.75" />
            </svg>
            <span
              id="circle-symbol"
              className="text-white text-[13px] lg:text-[15px] leading-none"
            >
              {currentSymbol}
            </span>
          </div>
          <span className="text-[11px] lg:text-[12px] tracking-wider uppercase font-bold text-white">
            {selectedDrinkName}
          </span>
        </div>

        {/* Collection label */}
        <h2 className="w-full text-center lg:text-left text-[22px] lg:text-[32px] leading-none tracking-[-0.04em] uppercase text-white font-extrabold">
          BỘ SƯU TẬP TRÀ ĐẬM VỊ
          <br />
          &ldquo;PHÚC LONG 1968&rdquo;
        </h2>
      </div>

      {/* Price - Pure white */}
      <div className="w-full text-center lg:text-left text-[54px] lg:text-[76px] leading-none tracking-[-0.04em] text-white font-extrabold">
        {selectedDrinkPrice}
      </div>
    </motion.div>
  );
}
