import { motion } from 'motion/react';

interface PhucLongLogoProps {
  onHomeClick?: () => void;
}

export function PhucLongLogo({ onHomeClick }: PhucLongLogoProps) {
  return (
    <motion.div
      className="fixed z-30 pointer-events-auto select-none left-4 top-4 lg:left-8 lg:top-8 cursor-pointer group"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.6,
        ease: [0.25, 0.1, 0.25, 1],
        delay: 0,
      }}
      onClick={onHomeClick}
    >
      <div className="flex items-center gap-3">
        {/* Phuc Long Emerald Badge SVG */}
        <div className="relative w-12 h-12 lg:w-16 lg:h-16 rounded-xl bg-[#006a38] text-white flex items-center justify-center shadow-lg border border-[#008f4c]/40 transition-transform duration-300 group-hover:scale-105">
          <svg
            viewBox="0 0 100 100"
            className="w-9 h-9 lg:w-12 lg:h-12"
            fill="none"
            stroke="currentColor"
          >
            {/* Ornate cup with steam */}
            <path
              d="M26 42 C26 62, 38 72, 50 72 C62 72, 74 62, 74 42 Z"
              fill="white"
            />
            {/* Cup handle */}
            <path
              d="M72 46 C82 46, 85 58, 73 62"
              stroke="white"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
            />
            {/* Saucer */}
            <path
              d="M20 78 Q50 86 80 78"
              stroke="white"
              strokeWidth="5"
              strokeLinecap="round"
            />
            {/* Steam curve */}
            <path
              d="M40 34 C42 26, 40 22, 45 16"
              stroke="white"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            <path
              d="M55 32 C58 24, 56 20, 60 14"
              stroke="white"
              strokeWidth="3.5"
              strokeLinecap="round"
            />
            <circle cx="50" cy="54" r="5" fill="#006a38" />
          </svg>
        </div>

        {/* Brand Text - Pure White Always */}
        <div className="flex flex-col text-white drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
          <div className="flex items-center gap-1.5">
            <span className="font-extrabold text-[22px] lg:text-[32px] tracking-[-0.04em] uppercase leading-none text-white">
              PHÚC LONG
            </span>
            <span className="text-[10px] lg:text-[12px] font-bold border border-white/60 px-1 py-0.2 rounded-full leading-none text-white">
              ®
            </span>
          </div>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[10px] lg:text-[11px] font-semibold tracking-wider text-white uppercase">
              SINCE 1968
            </span>
            <span className="w-1 h-1 rounded-full bg-white" />
            <span className="text-[10px] lg:text-[11px] font-semibold tracking-wider text-white uppercase">
              TEA & COFFEE
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
