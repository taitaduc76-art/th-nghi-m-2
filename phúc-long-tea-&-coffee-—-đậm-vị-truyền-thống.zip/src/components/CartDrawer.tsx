import { useState, type FormEvent } from 'react';
import type { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}: CartDrawerProps) {
  const [promoCode, setPromoCode] = useState<string>('');
  const [discountApplied, setDiscountApplied] = useState<boolean>(false);
  const [promoMessage, setPromoMessage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [isOrdered, setIsOrdered] = useState<boolean>(false);

  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerAddress, setCustomerAddress] = useState<string>('');
  const [orderNote, setOrderNote] = useState<string>('');

  if (!isOpen) return null;

  const rawSubtotal = items.reduce((acc, item) => {
    const toppingAddon = item.topping === 'Không thêm topping' ? 0 : 10000;
    return acc + (item.drink.price + toppingAddon) * item.quantity;
  }, 0);

  const discountAmount = discountApplied ? Math.round(rawSubtotal * 0.15) : 0;
  const shippingFee = items.length > 0 ? (rawSubtotal >= 120000 ? 0 : 15000) : 0;
  const grandTotal = Math.max(0, rawSubtotal - discountAmount + shippingFee);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'PHUCLONG1968' || promoCode.trim().toUpperCase() === 'PHUCLONG') {
      setDiscountApplied(true);
      setPromoMessage('Áp dụng mã thành công: Giảm 15%');
    } else {
      setPromoMessage('Mã không hợp lệ. Hãy thử: PHUCLONG1968');
    }
  };

  const handleCheckout = (e: FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
      setErrorMessage('Vui lòng điền đầy đủ Họ tên, Số điện thoại và Địa chỉ giao hàng!');
      return;
    }
    setErrorMessage('');
    setIsOrdered(true);
  };

  const handleFinishOrder = () => {
    setIsOrdered(false);
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-md bg-[#091710] border-l border-emerald-800/60 shadow-2xl h-full flex flex-col z-10 text-white">
        {/* Header */}
        <div className="p-5 border-b border-emerald-900/60 flex items-center justify-between bg-[#06120c]">
          <div className="flex items-center gap-2">
            <span className="text-xl">🛍️</span>
            <h3 className="font-extrabold text-lg uppercase tracking-tight text-white">
              GIỎ HÀNG CỦA BẠN ({items.reduce((sum, i) => sum + i.quantity, 0)})
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-900 hover:bg-neutral-800 text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
            aria-label="Đóng giỏ hàng"
          >
            ✕
          </button>
        </div>

        {/* Ordered Confirmation State */}
        {isOrdered ? (
          <div className="p-6 flex-1 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#006a38] text-white flex items-center justify-center text-3xl shadow-xl shadow-emerald-900/50">
              ✓
            </div>
            <h4 className="text-xl font-black uppercase text-white">
              ĐẶT HÀNG THÀNH CÔNG!
            </h4>
            <p className="text-sm text-neutral-300">
              Cảm ơn bạn <strong className="text-white">{customerName}</strong>! Đơn hàng Phúc Long của bạn đang được pha chế và giao đến{' '}
              <strong className="text-white">{customerAddress}</strong> trong vòng 20 - 30 phút.
            </p>
            <div className="bg-[#0f281d] border border-emerald-800/50 p-4 rounded-xl w-full text-xs text-left space-y-1.5">
              <div className="flex justify-between">
                <span className="text-neutral-400">Mã đơn hàng:</span>
                <span className="font-bold text-amber-400">PL-{Math.floor(100000 + Math.random() * 900000)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Số điện thoại:</span>
                <span className="font-bold text-white">{customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Tổng thanh toán:</span>
                <span className="font-bold text-emerald-400">{grandTotal.toLocaleString('vi-VN')}₫ (COD)</span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleFinishOrder}
              className="w-full py-3 bg-[#006a38] hover:bg-[#008f4c] text-white font-bold rounded-xl uppercase tracking-wider text-xs transition-colors"
            >
              Tiếp Tục Khám Phá Phúc Long
            </button>
          </div>
        ) : (
          <>
            {/* Items List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {items.length === 0 ? (
                <div className="py-16 text-center text-neutral-400 text-sm space-y-2">
                  <div className="text-4xl mb-2">🍵</div>
                  <p>Giỏ hàng của bạn đang trống.</p>
                  <p className="text-xs text-neutral-500">
                    Hãy lướt menu để chọn cho mình ly trà Phúc Long thơm ngon nhé!
                  </p>
                </div>
              ) : (
                items.map((item, idx) => {
                  const itemTotal =
                    (item.drink.price + (item.topping === 'Không thêm topping' ? 0 : 10000)) *
                    item.quantity;

                  return (
                    <div
                      key={idx}
                      className="bg-[#0f281d] border border-emerald-900/50 rounded-xl p-3 flex gap-3 items-center"
                    >
                      <img
                        src={item.drink.image}
                        alt={item.drink.name}
                        className="w-16 h-16 rounded-lg object-cover bg-black"
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <h5 className="text-xs font-bold uppercase text-white truncate">
                            {item.drink.name}
                          </h5>
                          <button
                            type="button"
                            onClick={() => onRemoveItem(idx)}
                            className="text-neutral-400 hover:text-red-400 text-xs px-1"
                            title="Xóa món"
                          >
                            ✕
                          </button>
                        </div>

                        <div className="text-[11px] text-neutral-400 mt-0.5 space-x-1 truncate">
                          <span>{item.sugar}</span>
                          <span>•</span>
                          <span>{item.ice}</span>
                        </div>
                        {item.topping !== 'Không thêm topping' && (
                          <div className="text-[10px] text-emerald-400 truncate">
                            +{item.topping}
                          </div>
                        )}

                        <div className="flex items-center justify-between mt-2 pt-1 border-t border-emerald-900/40">
                          <span className="text-xs font-black text-amber-400">
                            {itemTotal.toLocaleString('vi-VN')}₫
                          </span>

                          <div className="flex items-center border border-neutral-700 rounded bg-neutral-900 text-xs">
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(idx, Math.max(1, item.quantity - 1))}
                              className="w-5 h-5 flex items-center justify-center text-white"
                            >
                              -
                            </button>
                            <span className="w-5 text-center font-bold">{item.quantity}</span>
                            <button
                              type="button"
                              onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                              className="w-5 h-5 flex items-center justify-center text-white"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Order Checkout Form & Summary */}
            {items.length > 0 && (
              <div className="p-4 bg-[#06120c] border-t border-emerald-900/60 space-y-3">
                {/* Promo Code Input */}
                <div className="flex flex-col gap-1">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="Mã giảm giá (Nhập: PHUCLONG1968)"
                      className="flex-1 text-xs bg-neutral-900 border border-neutral-700 rounded px-2.5 py-1.5 text-white placeholder:text-neutral-500 focus:outline-none focus:border-emerald-500 uppercase"
                    />
                    <button
                      type="button"
                      onClick={handleApplyPromo}
                      className="text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-white px-3 py-1.5 rounded transition-colors cursor-pointer"
                    >
                      Áp dụng
                    </button>
                  </div>
                  {promoMessage && (
                    <div className={`text-[11px] font-medium ${discountApplied ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {promoMessage}
                    </div>
                  )}
                </div>

                {/* Price Breakdown */}
                <div className="text-xs text-neutral-300 space-y-1 pt-1 border-t border-emerald-900/40">
                  <div className="flex justify-between">
                    <span>Tạm tính:</span>
                    <span>{rawSubtotal.toLocaleString('vi-VN')}₫</span>
                  </div>
                  {discountApplied && (
                    <div className="flex justify-between text-emerald-400">
                      <span>Giảm giá (15% PHUCLONG1968):</span>
                      <span>-{discountAmount.toLocaleString('vi-VN')}₫</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Phí giao hàng:</span>
                    <span>{shippingFee === 0 ? 'Miễn phí' : `${shippingFee.toLocaleString('vi-VN')}₫`}</span>
                  </div>
                  <div className="flex justify-between font-black text-sm text-white pt-1 border-t border-emerald-900/40">
                    <span>Tổng thanh toán:</span>
                    <span className="text-amber-400">{grandTotal.toLocaleString('vi-VN')}₫</span>
                  </div>
                </div>

                {/* Delivery Form */}
                <form onSubmit={handleCheckout} className="space-y-2 pt-2 border-t border-emerald-900/40">
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Họ tên người nhận *"
                    className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded p-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="Số điện thoại *"
                      className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded p-1.5 text-white focus:outline-none focus:border-emerald-500"
                    />
                    <input
                      type="text"
                      value={orderNote}
                      onChange={(e) => setOrderNote(e.target.value)}
                      placeholder="Ghi chú thêm"
                      className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded p-1.5 text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <input
                    type="text"
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder="Địa chỉ giao hàng chi tiết *"
                    className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded p-1.5 text-white focus:outline-none focus:border-emerald-500"
                  />

                  {errorMessage && (
                    <div className="text-[11px] text-red-400 font-medium">
                      {errorMessage}
                    </div>
                  )}

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-[#006a38] hover:bg-[#008f4c] text-white font-extrabold rounded-xl uppercase tracking-wider text-xs transition-colors shadow-lg shadow-emerald-900/50 cursor-pointer mt-1"
                  >
                    Xác Nhận Đặt Giao Hàng (COD)
                  </button>
                </form>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
