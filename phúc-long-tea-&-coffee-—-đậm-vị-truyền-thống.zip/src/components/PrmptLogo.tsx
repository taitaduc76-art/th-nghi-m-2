import { motion } from 'motion/react';

export function PrmptLogo() {
  return (
    <motion.div
      id="prmpt-logo"
      className="fixed pointer-events-none z-20 top-4 left-4 lg:top-8 lg:left-8 w-[124px] sm:w-[266px] lg:w-[355px] drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.6,
        ease: [0.25, 0.1, 0.25, 1],
        delay: 0,
      }}
    >
      <svg
        width="355"
        height="110"
        viewBox="0 0 355 110"
        fill="white"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto"
      >
        {/* prmpt wordmark */}
        <text
          x="0"
          y="80"
          fill="white"
          fontFamily="'Inter Tight', 'Helvetica Neue', Helvetica, Arial, sans-serif"
          fontWeight="700"
          fontSize="84"
          letterSpacing="-4"
        >
          prmpt
        </text>

        {/* Circled R mark */}
        <circle cx="320" cy="35" r="15" stroke="white" strokeWidth="2" fill="none" />
        <text
          x="314"
          y="41"
          fill="white"
          fontFamily="'Inter Tight', 'Helvetica Neue', Helvetica, Arial, sans-serif"
          fontSize="16"
          fontWeight="700"
        >
          R
        </text>
      </svg>
    </motion.div>
  );
}
