import { useState } from 'react';
import type { DrinkProduct, CartItem } from '../types';

interface DrinkDetailModalProps {
  drink: DrinkProduct | null;
  onClose: () => void;
  onAddToCart: (item: CartItem) => void;
}

export function DrinkDetailModal({
  drink,
  onClose,
  onAddToCart,
}: DrinkDetailModalProps) {
  const [sugar, setSugar] = useState<string>('100% Tiêu chuẩn');
  const [ice, setIce] = useState<string>('100% Tiêu chuẩn');
  const [topping, setTopping] = useState<string>('Không thêm topping');
  const [quantity, setQuantity] = useState<number>(1);
  const [added, setAdded] = useState<boolean>(false);

  if (!drink) return null;

  const toppingPrice = topping === 'Không thêm topping' ? 0 : 10000;
  const totalPrice = (drink.price + toppingPrice) * quantity;
  const formattedTotalPrice = `${totalPrice.toLocaleString('vi-VN')}₫`;

  const handleAdd = () => {
    onAddToCart({
      drink,
      quantity,
      sugar,
      ice,
      topping,
    });
    setAdded(true);
    setTimeout(() => {
      setAdded(false);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md animate-fadeIn">
      {/* Click outside to close */}
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-2xl bg-[#0b1c14] border border-emerald-800/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh] z-10 text-white">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
          aria-label="Đóng chi tiết đồ uống"
        >
          ✕
        </button>

        {/* Drink Image Column */}
        <div className="relative w-full md:w-5/12 h-64 md:h-auto min-h-[260px] bg-black">
          <img
            src={drink.image}
            alt={drink.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b1c14] via-transparent to-transparent md:hidden" />
          {drink.badge && (
            <div className="absolute top-4 left-4">
              <span className="bg-[#006a38] text-white text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border border-emerald-400/40 shadow-lg">
                {drink.badge}
              </span>
            </div>
          )}
        </div>

        {/* Drink Information & Options Column */}
        <div className="w-full md:w-7/12 p-6 overflow-y-auto flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-widest mb-1">
              {drink.englishName}
            </div>
            <h3 className="text-2xl lg:text-3xl font-black text-white uppercase tracking-tight">
              {drink.name}
            </h3>

            <div className="flex items-center gap-3 mt-2">
              <span className="text-2xl font-extrabold text-amber-400">
                {drink.formattedPrice}
              </span>
              {drink.calories && (
                <span className="text-xs bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded">
                  {drink.calories}
                </span>
              )}
            </div>

            <p className="text-sm text-neutral-300 mt-3 leading-relaxed">
              {drink.description}
            </p>

            {/* Flavor Notes */}
            <div className="mt-4">
              <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
                Điểm nhấn hương vị:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {drink.tasteNotes.map((note, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] font-medium bg-emerald-900/50 text-emerald-200 border border-emerald-700/40 px-2 py-0.5 rounded-full"
                  >
                    ✓ {note}
                  </span>
                ))}
              </div>
            </div>

            {/* Origin & Ingredients */}
            <div className="mt-4 pt-3 border-t border-emerald-900/50 text-xs text-neutral-300 space-y-1">
              <div>
                <strong className="text-neutral-400">Xuất xứ trà:</strong>{' '}
                {drink.origin}
              </div>
              <div>
                <strong className="text-neutral-400">Thành phần:</strong>{' '}
                {drink.ingredients}
              </div>
            </div>

            {/* Customization Options */}
            <div className="mt-4 pt-3 border-t border-emerald-900/50 space-y-3">
              {/* Sugar */}
              <div>
                <label className="text-xs font-bold text-neutral-300 block mb-1">
                  Độ ngọt (Đường):
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {['100% Tiêu chuẩn', '70% Vừa', '50% Ít ngọt'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setSugar(opt)}
                      className={`text-[11px] py-1 px-1.5 rounded text-center border font-medium transition-colors cursor-pointer ${
                        sugar === opt
                          ? 'bg-[#006a38] border-emerald-400 text-white'
                          : 'bg-neutral-900 border-neutral-700 text-neutral-300 hover:border-neutral-500'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ice */}
              <div>
                <label className="text-xs font-bold text-neutral-300 block mb-1">
                  Độ lạnh (Đá):
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {['100% Tiêu chuẩn', '70% Ít đá', 'Không đá'].map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setIce(opt)}
                      className={`text-[11px] py-1 px-1.5 rounded text-center border font-medium transition-colors cursor-pointer ${
                        ice === opt
                          ? 'bg-[#006a38] border-emerald-400 text-white'
                          : 'bg-neutral-900 border-neutral-700 text-neutral-300 hover:border-neutral-500'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Topping */}
              <div>
                <label className="text-xs font-bold text-neutral-300 block mb-1">
                  Thêm Topping (+10.000₫):
                </label>
                <select
                  value={topping}
                  onChange={(e) => setTopping(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded p-1.5 text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Không thêm topping">Không thêm topping</option>
                  <option value="Thạch dừa non dẻo (+10k)">Thạch dừa non dẻo mềm (+10.000₫)</option>
                  <option value="Nhãn lồng bọc hạt sen (+10k)">Nhãn lồng bọc hạt sen (+10.000₫)</option>
                  <option value="Thạch đào miếng giòn (+10k)">Thạch đào miếng giòn (+10.000₫)</option>
                  <option value="Thạch dừa giòn sần sật (+10k)">Thạch dừa giòn sần sật (+10.000₫)</option>
                  <option value="Trân châu trắng hoàng kim (+10k)">Trân châu trắng hoàng kim (+10.000₫)</option>
                  <option value="Hạt sen Bách Diệp (+10k)">Hạt sen Bách Diệp bùi béo (+10.000₫)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Action Footer */}
          <div className="mt-6 pt-4 border-t border-emerald-900/60 flex items-center justify-between gap-4">
            {/* Quantity */}
            <div className="flex items-center border border-neutral-700 rounded-lg bg-neutral-900">
              <button
                type="button"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-8 h-8 flex items-center justify-center text-white hover:bg-neutral-800 transition-colors"
              >
                -
              </button>
              <span className="w-8 text-center font-bold text-sm text-white">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity(quantity + 1)}
                className="w-8 h-8 flex items-center justify-center text-white hover:bg-neutral-800 transition-colors"
              >
                +
              </button>
            </div>

            {/* Add to Cart Button */}
            <button
              type="button"
              onClick={handleAdd}
              disabled={added}
              className={`flex-1 py-2.5 px-4 rounded-xl font-bold text-sm uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer ${
                added
                  ? 'bg-emerald-500 text-white scale-98'
                  : 'bg-[#006a38] hover:bg-[#008f4c] text-white shadow-lg shadow-emerald-900/50'
              }`}
            >
              {added ? (
                <>✓ Đã Thêm Vào Giỏ!</>
              ) : (
                <>
                  <span>Thêm Vào Giỏ</span>
                  <span>•</span>
                  <span>{formattedTotalPrice}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
