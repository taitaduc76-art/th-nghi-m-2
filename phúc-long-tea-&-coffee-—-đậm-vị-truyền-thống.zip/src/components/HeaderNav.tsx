import { motion } from 'motion/react';

interface HeaderNavProps {
  cartCount?: number;
  onOpenCart?: () => void;
  onOpenMenu?: () => void;
  onOpenStory?: () => void;
}

export function HeaderNav({
  cartCount = 0,
  onOpenCart,
  onOpenMenu,
  onOpenStory,
}: HeaderNavProps) {
  return (
    <motion.header
      id="header-nav"
      className="fixed z-30 top-4 right-4 lg:top-8 lg:right-8 w-auto h-[36px] flex flex-row items-center gap-4 lg:gap-8 text-white select-none pointer-events-auto drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.6,
        ease: [0.25, 0.1, 0.25, 1],
        delay: 0.15,
      }}
    >
      {/* "CÂU CHUYỆN" (Heritage Story) */}
      <button
        type="button"
        onClick={onOpenStory}
        className="hidden md:inline-block text-[13px] lg:text-[14px] font-bold tracking-wider uppercase hover:text-emerald-300 transition-colors cursor-pointer text-white drop-shadow"
      >
        CÂU CHUYỆN 1968
      </button>

      {/* "THỰC ĐƠN" */}
      <button
        type="button"
        onClick={onOpenMenu}
        className="hidden sm:inline-block text-[13px] lg:text-[14px] font-bold tracking-wider uppercase hover:text-emerald-300 transition-colors cursor-pointer text-white drop-shadow"
      >
        MENU ĐẶC TRƯNG
      </button>

      <div className="flex flex-row items-center gap-3 sm:gap-6">
        {/* Hamburger Icon button */}
        <button
          type="button"
          onClick={onOpenMenu}
          aria-label="Mở danh mục đồ uống Phúc Long"
          className="p-1 hover:text-emerald-300 transition-colors cursor-pointer flex items-center justify-center text-white drop-shadow"
        >
          <svg
            viewBox="0 0 40 40"
            className="w-[24px] h-[24px] lg:w-[28px] lg:h-[28px]"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.8"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path d="M0 14H40M0 26H40" />
          </svg>
        </button>

        {/* [ GIỎ HÀNG ] button */}
        <button
          type="button"
          onClick={onOpenCart}
          className="text-[13px] lg:text-[14px] font-bold uppercase whitespace-nowrap hover:bg-white/20 transition-all cursor-pointer bg-black/40 backdrop-blur-md border border-white/80 px-3 py-1 rounded-full text-white flex items-center gap-2 shadow-lg"
        >
          <span>GIỎ HÀNG</span>
          <span className="bg-[#006a38] text-white font-bold text-[11px] px-2 py-0.5 rounded-full border border-emerald-400/40">
            {cartCount}
          </span>
        </button>
      </div>
    </motion.header>
  );
}
