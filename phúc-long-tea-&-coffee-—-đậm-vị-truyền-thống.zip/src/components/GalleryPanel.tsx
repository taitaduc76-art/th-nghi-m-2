import { forwardRef, useState, type RefObject } from 'react';
import { PHUCLONG_DRINKS, TERRACED_TEA_HILLS_BACKGROUND, MEADOW_HILLS_BACKGROUND } from '../data';
import type { DrinkProduct } from '../types';

interface GalleryPanelProps {
  cols: number;
  layoutRows: number[][];
  innerWrapperRef: RefObject<HTMLDivElement | null>;
  onSelectDrink?: (drink: DrinkProduct) => void;
}

export const GalleryPanel = forwardRef<HTMLDivElement, GalleryPanelProps>(
  ({ cols, layoutRows, innerWrapperRef, onSelectDrink }, ref) => {
    const [themeArt, setThemeArt] = useState<'terraces' | 'meadow'>('terraces');

    const activeArtImage = themeArt === 'terraces' ? TERRACED_TEA_HILLS_BACKGROUND : MEADOW_HILLS_BACKGROUND;

    return (
      <div
        ref={ref}
        id="black-panel"
        className="fixed inset-0 bg-[#05130b] z-10 overflow-hidden pointer-events-none"
        style={{
          transform: 'translateY(100vh)',
          willChange: 'transform',
        }}
      >
        {/* Scenic Highland Terraced Tea Hills Background (Anime/Ghibli Watercolor Art) */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden select-none">
          <img
            src={activeArtImage}
            alt="Đồi trà xanh bậc thang ngút ngàn"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 transition-all duration-1000 ease-out filter brightness-[0.72] contrast-[1.08] saturate-[1.15]"
          />

          {/* Painterly atmosphere & contrast overlays */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#06140e]/95 via-[#061810]/55 to-[#020b06]/95 pointer-events-none" />
          <div className="absolute inset-0 bg-radial from-transparent via-[#004822]/15 to-[#020b06]/70 pointer-events-none" />

          {/* Gentle tea leaf pattern overlay */}
          <div className="absolute inset-0 opacity-[0.04] bg-[radial-gradient(#4ade80_1.5px,transparent_1.5px)] [background-size:28px_28px] pointer-events-none" />
        </div>

        {/* Inner Wrapper */}
        <div
          ref={innerWrapperRef}
          id="gallery-inner-wrapper"
          className="w-full pointer-events-none relative z-10"
          style={{
            paddingTop: 'min(360px, 32vh)',
            willChange: 'transform',
          }}
        >
          {/* Section header banner inside panel */}
          <div className="px-6 md:px-14 lg:px-20 mb-8 max-w-[1920px] mx-auto flex flex-col md:flex-row md:items-end justify-between gap-4 text-white/90">
            <div>
              <div className="flex items-center gap-2 text-[#4ade80] text-xs font-bold uppercase tracking-widest mb-1.5">
                <span className="animate-pulse">🍃</span>
                <span>CAO NGUYÊN BẢO LỘC — BỘ SƯU TẬP ĐỒ UỐNG TRUYỀN THỐNG</span>
              </div>
              <h3 className="text-2xl md:text-3xl lg:text-4xl font-extrabold uppercase tracking-tight text-white drop-shadow-md">
                HƯƠNG VỊ ĐẬM ĐÀ TỪ NĂM 1968
              </h3>
              <p className="text-xs text-white/70 mt-1 max-w-xl">
                Băng qua những triền đồi bạt ngàn nắng sớm, chắt chiu tinh hoa đất trời trong từng tách trà thơm ngát.
              </p>
            </div>

            {/* Scenery Style Toggle */}
            <div className="pointer-events-auto flex items-center gap-2 self-start md:self-end bg-black/60 backdrop-blur-md border border-white/15 rounded-full p-1 text-[11px] font-semibold text-white/80">
              <button
                type="button"
                onClick={() => setThemeArt('terraces')}
                className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
                  themeArt === 'terraces'
                    ? 'bg-[#006a38] text-white font-bold shadow'
                    : 'hover:text-white'
                }`}
              >
                Đồi Trà Bậc Thang
              </button>
              <button
                type="button"
                onClick={() => setThemeArt('meadow')}
                className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
                  themeArt === 'meadow'
                    ? 'bg-[#006a38] text-white font-bold shadow'
                    : 'hover:text-white'
                }`}
              >
                Đồng Cỏ Thả Diều
              </button>
            </div>
          </div>

          {/* Scattered grid */}
          <div
            className="grid gap-6 sm:gap-8 lg:gap-14 px-4 sm:px-8 lg:px-16 pb-48 w-full max-w-[1920px] mx-auto"
            style={{
              gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
            }}
          >
            {layoutRows.map((row, rIdx) =>
              row.map((imgIdx, cIdx) => {
                if (imgIdx === -1) {
                  return (
                    <div
                      key={`empty-${rIdx}-${cIdx}`}
                      className="w-full aspect-[2/3] pointer-events-none"
                      aria-hidden="true"
                    />
                  );
                }

                const drink = PHUCLONG_DRINKS[imgIdx % PHUCLONG_DRINKS.length];
                const isLeftHalf = cIdx < cols / 2;
                const transformOrigin = isLeftHalf ? 'right bottom' : 'left bottom';

                return (
                  <div
                    key={`card-slot-${imgIdx}-${rIdx}`}
                    className="cell-slot relative w-full aspect-[2/3] select-none"
                  >
                    <div
                      className="bp-card absolute inset-0 w-full h-full overflow-hidden bg-[#0c2319] shadow-2xl rounded-xl border border-emerald-900/40 pointer-events-auto cursor-pointer group"
                      style={{
                        transform: 'scale(0)',
                        transformOrigin,
                      }}
                      onClick={() => onSelectDrink && onSelectDrink(drink)}
                    >
                      {/* Drink Image */}
                      <img
                        src={drink.image}
                        alt={drink.name}
                        className="w-full h-full object-cover select-none transition-transform duration-700 group-hover:scale-105"
                        loading="eager"
                        decoding="async"
                      />

                      {/* Dark gradient overlay for text readability */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent pointer-events-none" />

                      {/* Top Badge */}
                      {drink.badge && (
                        <div className="absolute top-3 left-3 pointer-events-none">
                          <span className="bg-[#006a38] text-white text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-emerald-400/30 shadow-md">
                            {drink.badge}
                          </span>
                        </div>
                      )}

                      {/* Bottom Info Card */}
                      <div className="absolute bottom-0 inset-x-0 p-4 lg:p-5 pointer-events-none flex flex-col gap-1 text-white">
                        <div className="text-[11px] font-semibold text-emerald-300 uppercase tracking-wider">
                          {drink.englishName}
                        </div>
                        <h4 className="text-[17px] lg:text-[20px] font-extrabold uppercase leading-tight text-white group-hover:text-emerald-300 transition-colors">
                          {drink.name}
                        </h4>
                        <div className="flex items-center justify-between mt-1 pt-1.5 border-t border-white/20">
                          <span className="text-[16px] lg:text-[18px] font-black text-amber-400">
                            {drink.formattedPrice}
                          </span>
                          <span className="text-[11px] font-bold bg-white/15 text-white px-2 py-0.5 rounded group-hover:bg-white group-hover:text-black transition-colors">
                            Xem chi tiết +
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    );
  }
);

GalleryPanel.displayName = 'GalleryPanel';
