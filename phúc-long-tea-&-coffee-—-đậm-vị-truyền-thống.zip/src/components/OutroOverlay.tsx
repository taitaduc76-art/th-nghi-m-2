import { OUTRO_KITE_BACKGROUND } from '../data';

interface OutroOverlayProps {
  onExploreClick?: () => void;
}

export function OutroOverlay({ onExploreClick }: OutroOverlayProps) {
  return (
    <>
      {/* Outro Scenic Artwork Overlay (Boy flying kite over green highland tea hills) */}
      <div
        id="outro-overlay"
        className="fixed inset-0 pointer-events-none z-12 overflow-hidden bg-[#07180f]"
        style={{ opacity: 0 }}
      >
        <img
          src={OUTRO_KITE_BACKGROUND}
          alt="Thả diều trên đồi trà xanh ngát"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105"
        />

        {/* Ambient atmospheric gradients for depth and text legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#041009]/90 via-transparent to-black/30 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/30 pointer-events-none" />

        {/* Poetic Heritage Headline in Outro */}
        <div className="absolute top-1/4 sm:top-1/3 left-6 sm:left-12 lg:left-20 max-w-xl text-white pointer-events-none drop-shadow-lg">
          <div className="flex items-center gap-2 text-emerald-300 text-xs sm:text-sm font-bold uppercase tracking-widest mb-2">
            <span>🪁</span>
            <span>HƯƠNG VỊ CAO NGUYÊN VIỆT NAM</span>
          </div>
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight leading-tight text-white drop-shadow-md">
            TRỌN VỊ NGUYÊN BẢN
          </h2>
          <p className="mt-3 text-sm sm:text-base text-white/90 font-medium leading-relaxed drop-shadow">
            Từ những ngọn đồi trà bạt ngàn nắng gió Bảo Lộc năm 1968 đến từng tách trà thơm thảo đậm đà trao tận tay bạn.
          </p>
        </div>
      </div>

      {/* "KHÁM PHÁ THỰC ĐƠN" Button (Initially Hidden, scales via scroll) */}
      <button
        type="button"
        id="outro-buy"
        onClick={onExploreClick}
        aria-label="Khám phá toàn bộ thực đơn Phúc Long"
        className="fixed pointer-events-auto z-20 flex items-center justify-center bg-[#006a38] text-white border-2 border-emerald-400/60 shadow-2xl rounded-[1335px] left-4 right-4 bottom-[60px] h-[96px] lg:left-auto lg:right-8 lg:bottom-8 lg:w-[340px] lg:h-[150px] select-none cursor-pointer group hover:bg-[#00522b] hover:scale-105 active:scale-95 transition-all"
        style={{
          transformOrigin: 'right bottom',
          transform: 'scale(0)',
        }}
      >
        <span className="font-extrabold text-[36px] lg:text-[50px] tracking-[-0.03em] leading-none uppercase select-none flex items-center gap-3 drop-shadow-md text-white">
          <span>MENU</span>
          <span className="text-2xl lg:text-3xl transition-transform duration-300 group-hover:rotate-12">🍃</span>
        </span>
      </button>

      {/* Footer */}
      <footer
        id="outro-footer"
        className="fixed pointer-events-none z-20 left-4 lg:left-8 bottom-6 lg:bottom-8 flex flex-row flex-wrap gap-4 lg:gap-14 text-white/95 font-semibold text-[11px] lg:text-[13px] tracking-[-0.02em] uppercase select-none drop-shadow-md"
        style={{ opacity: 0 }}
      >
        <span>PHÚC LONG TEA & COFFEE © 1968 - 2026</span>
        <span className="hidden sm:inline">HỆ THỐNG CỬA HÀNG TOÀN QUỐC</span>
        <span>HOTLINE GIAO HÀNG: 1800 6779</span>
      </footer>
    </>
  );
}
