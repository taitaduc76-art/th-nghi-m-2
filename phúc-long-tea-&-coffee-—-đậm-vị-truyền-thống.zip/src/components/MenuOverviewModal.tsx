import { useState, useMemo } from 'react';
import { PHUCLONG_DRINKS } from '../data';
import type { DrinkProduct, DrinkCategory } from '../types';

interface MenuOverviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectDrink: (drink: DrinkProduct) => void;
}

export function MenuOverviewModal({
  isOpen,
  onClose,
  onSelectDrink,
}: MenuOverviewModalProps) {
  const [selectedCategory, setSelectedCategory] = useState<DrinkCategory>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredDrinks = useMemo(() => {
    return PHUCLONG_DRINKS.filter((drink) => {
      const matchesCategory =
        selectedCategory === 'all' || drink.category === selectedCategory;
      const matchesSearch =
        drink.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        drink.englishName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        drink.description.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-4xl bg-[#091710] border border-emerald-800/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10 text-white">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-emerald-900/60 flex items-center justify-between bg-[#06120c]">
          <div>
            <div className="flex items-center gap-2 text-[#4ade80] text-xs font-bold uppercase tracking-widest">
              <span>🍃</span>
              <span>PHÚC LONG COFFEE & TEA</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black uppercase text-white tracking-tight mt-0.5">
              THỰC ĐƠN ĐỒ UỐNG ĐẶC TRƯNG
            </h3>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-neutral-900 hover:bg-neutral-800 text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
            aria-label="Đóng thực đơn"
          >
            ✕
          </button>
        </div>

        {/* Filter and Search Bar */}
        <div className="p-4 sm:px-6 bg-[#0c1e15] border-b border-emerald-900/40 flex flex-col sm:flex-row gap-3 items-center justify-between">
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1.5 w-full sm:w-auto">
            {[
              { id: 'all', label: 'Tất cả' },
              { id: 'tea', label: 'Trà Trái Cây' },
              { id: 'milktea', label: 'Trà Sữa' },
              { id: 'iceblended', label: 'Đá Xay & Tuyết' },
              { id: 'coffee', label: 'Cà Phê' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedCategory(tab.id as DrinkCategory)}
                className={`text-xs font-bold px-3 py-1.5 rounded-full transition-all cursor-pointer ${
                  selectedCategory === tab.id
                    ? 'bg-[#006a38] text-white border border-emerald-400/40 shadow-sm'
                    : 'bg-neutral-900/80 text-neutral-300 border border-neutral-700/60 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-60">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm món (Trà Đào, Vải Sen...)"
              className="w-full text-xs bg-neutral-900 border border-neutral-700 rounded-full px-3.5 py-1.5 text-white placeholder:text-neutral-500 focus:outline-none focus:border-emerald-500"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Drinks Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {filteredDrinks.map((drink) => (
            <div
              key={drink.id}
              onClick={() => {
                onClose();
                onSelectDrink(drink);
              }}
              className="group bg-[#0f281d] border border-emerald-900/50 hover:border-emerald-500/60 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-xl flex flex-col"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-black">
                <img
                  src={drink.image}
                  alt={drink.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                {drink.badge && (
                  <span className="absolute top-2 left-2 bg-[#006a38] text-white text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-400/40">
                    {drink.badge}
                  </span>
                )}
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider">
                    {drink.englishName}
                  </div>
                  <h4 className="text-base font-extrabold text-white group-hover:text-emerald-300 transition-colors uppercase mt-0.5">
                    {drink.name}
                  </h4>
                  <p className="text-xs text-neutral-400 line-clamp-2 mt-1">
                    {drink.description}
                  </p>
                </div>

                <div className="flex items-center justify-between mt-3 pt-2 border-t border-emerald-900/60">
                  <span className="text-base font-black text-amber-400">
                    {drink.formattedPrice}
                  </span>
                  <span className="text-xs font-bold text-white bg-[#006a38] px-2.5 py-1 rounded group-hover:bg-[#008f4c] transition-colors">
                    Chọn món +
                  </span>
                </div>
              </div>
            </div>
          ))}

          {filteredDrinks.length === 0 && (
            <div className="col-span-full py-12 text-center text-neutral-400 text-sm">
              Không tìm thấy đồ uống phù hợp với từ khóa &ldquo;{searchQuery}&rdquo;.
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 sm:px-6 bg-[#06120c] border-t border-emerald-900/60 flex items-center justify-between text-xs text-neutral-400">
          <span>Cam kết 100% nguyên liệu tự nhiên từ Bảo Lộc</span>
          <span className="text-emerald-400 font-semibold">Hotline: 1800 6779</span>
        </div>
      </div>
    </div>
  );
}
