import { HERO_BACKGROUND } from '../data';

interface StoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExploreMenu: () => void;
}

export function StoryModal({ isOpen, onClose, onExploreMenu }: StoryModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="relative w-full max-w-3xl bg-[#091710] border border-emerald-800/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh] z-10 text-white">
        {/* Hero banner */}
        <div className="relative h-48 sm:h-64 w-full overflow-hidden">
          <img
            src={HERO_BACKGROUND}
            alt="Tôn vinh di sản Phúc Long 1968"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#091710] via-black/40 to-transparent" />

          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-black/60 hover:bg-black/90 text-white flex items-center justify-center border border-white/20 transition-colors cursor-pointer"
            aria-label="Đóng câu chuyện Phúc Long"
          >
            ✕
          </button>

          <div className="absolute bottom-4 left-6">
            <span className="text-emerald-400 text-xs font-bold uppercase tracking-widest bg-black/50 px-2.5 py-0.5 rounded">
              DI SẢN TRÀ & CÀ PHÊ VIỆT
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight mt-1">
              CÂU CHUYỆN PHÚC LONG TỪ 1968
            </h3>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-neutral-300 text-sm leading-relaxed">
          <p className="text-base text-emerald-100 font-medium leading-relaxed italic border-l-2 border-emerald-400 pl-4">
            &ldquo;Hơn 50 năm chắt chiu từng giọt đậm đà, Phúc Long tự hào là thương hiệu trà và cà phê mang linh hồn cao nguyên đất Việt đến mọi thế hệ.&rdquo;
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            <div className="bg-[#0f2a1e] border border-emerald-800/40 p-4 rounded-xl">
              <div className="text-2xl mb-2">🌿</div>
              <h4 className="font-extrabold text-white text-base uppercase mb-1">
                Búp Trà Bảo Lộc
              </h4>
              <p className="text-xs text-neutral-300">
                Nằm ở độ cao trên 1.000m, quanh năm mây mù bao phủ, tạo nên những búp trà xanh mơn mởn, hàm lượng dưỡng chất và hương thơm thanh khiết đặc trưng.
              </p>
            </div>

            <div className="bg-[#0f2a1e] border border-emerald-800/40 p-4 rounded-xl">
              <div className="text-2xl mb-2">🍵</div>
              <h4 className="font-extrabold text-white text-base uppercase mb-1">
                Ủ Trà Bí Truyền
              </h4>
              <p className="text-xs text-neutral-300">
                Phương pháp ủ đậm truyền thống kết hợp công nghệ hiện đại giữ trọn vẹn vị chát êm dịu nơi đầu lưỡi và hậu vị ngọt sâu lắng nơi cuống họng.
              </p>
            </div>

            <div className="bg-[#0f2a1e] border border-emerald-800/40 p-4 rounded-xl">
              <div className="text-2xl mb-2">✨</div>
              <h4 className="font-extrabold text-white text-base uppercase mb-1">
                Sáng Tạo Đương Đại
              </h4>
              <p className="text-xs text-neutral-300">
                Tiên phong kết hợp búp trà truyền thống với trái cây nhiệt đới tươi mới như đào giòn, sen Bách Diệp, vải thiều và các dòng đá tuyết độc đáo.
              </p>
            </div>
          </div>

          <div className="pt-2 border-t border-emerald-900/50 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-neutral-400">
              Trụ sở & Nông trường: Cao nguyên Bảo Lộc, Lâm Đồng
            </div>

            <button
              type="button"
              onClick={() => {
                onClose();
                onExploreMenu();
              }}
              className="w-full sm:w-auto px-6 py-2.5 bg-[#006a38] hover:bg-[#008f4c] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg cursor-pointer"
            >
              Khám Phá Thực Đơn Ngay →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
