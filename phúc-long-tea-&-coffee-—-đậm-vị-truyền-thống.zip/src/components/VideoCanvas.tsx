import { useEffect, useRef, useState } from 'react';
import { HERITAGE_BANNER, TEA_HILLS_BACKGROUND, TERRACED_TEA_HILLS_BACKGROUND } from '../data';

interface VideoCanvasProps {
  isVisible: boolean;
}

export function VideoCanvas({ isVisible }: VideoCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  // View mode: 'heritage' (Tôn Vinh Di Sản), 'terraces' (Đồi Trà Bậc Thang), or 'teahills' (Đồi Trà Bảo Lộc)
  const [viewMode, setViewMode] = useState<'heritage' | 'terraces' | 'teahills'>('heritage');
  const [imageLoaded, setImageLoaded] = useState<boolean>(false);

  // Parallax cursor tracking
  const mouseRef = useRef<{ x: number; y: number; targetX: number; targetY: number }>({
    x: 0,
    y: 0,
    targetX: 0,
    targetY: 0,
  });

  useEffect(() => {
    const isTouch = window.matchMedia('(pointer: coarse)').matches;
    if (isTouch) return;

    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      // Normalized coordinates from -1 to 1
      mouseRef.current.targetX = (e.clientX / innerWidth - 0.5) * 2;
      mouseRef.current.targetY = (e.clientY / innerHeight - 0.5) * 2;
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    let rafId: number;
    const animateParallax = () => {
      // Smooth lerp
      mouseRef.current.x += (mouseRef.current.targetX - mouseRef.current.x) * 0.05;
      mouseRef.current.y += (mouseRef.current.targetY - mouseRef.current.y) * 0.05;

      if (imageRef.current) {
        const moveX = mouseRef.current.x * 16;
        const moveY = mouseRef.current.y * 12;
        imageRef.current.style.transform = `scale(1.05) translate(${moveX}px, ${moveY}px)`;
      }

      rafId = requestAnimationFrame(animateParallax);
    };

    rafId = requestAnimationFrame(animateParallax);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(rafId);
    };
  }, []);

  const currentBg =
    viewMode === 'heritage'
      ? HERITAGE_BANNER
      : viewMode === 'terraces'
      ? TERRACED_TEA_HILLS_BACKGROUND
      : TEA_HILLS_BACKGROUND;

  return (
    <div
      id="main-canvas"
      ref={containerRef}
      className="pointer-events-auto overflow-hidden transition-opacity duration-700 ease-out fixed left-0 top-[180px] w-screen h-[calc(100vh-180px)] lg:top-0 lg:left-0 lg:w-full lg:h-full z-0 select-none"
      style={{
        visibility: isVisible ? 'visible' : 'hidden',
        opacity: isVisible ? 1 : 0,
      }}
    >
      {/* Background Frame with Parallax */}
      <div className="absolute inset-0 bg-[#06140e] overflow-hidden flex items-center justify-center">
        <img
          ref={imageRef}
          key={currentBg}
          src={currentBg}
          alt={
            viewMode === 'heritage'
              ? 'Tôn Vinh Di Sản Phúc Long 1968'
              : viewMode === 'terraces'
              ? 'Đồi Trà Bậc Thang Phúc Long'
              : 'Đồi Trà Bảo Lộc'
          }
          referrerPolicy="no-referrer"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover object-center transition-all duration-1000 ease-out ${
            imageLoaded ? 'scale-105 opacity-95 blur-0' : 'scale-100 opacity-0 blur-sm'
          }`}
          style={{ willChange: 'transform' }}
        />

        {/* Ambient Overlays to enhance legibility and tea aesthetic */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#091710] via-transparent to-black/50 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-black/50 pointer-events-none" />
        <div className="absolute inset-0 bg-radial from-transparent via-[#004822]/10 to-[#040e08]/60 pointer-events-none" />
      </div>

      {/* Floating Heritage Badge on Top Hero */}
      <div className="absolute bottom-8 left-4 lg:left-8 z-10 flex flex-wrap items-center gap-3">
        <div className="bg-[#006a38]/85 backdrop-blur-md border border-emerald-400/30 rounded-full px-4 py-1.5 flex items-center gap-2 shadow-lg shadow-black/40">
          <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
          <span className="text-[11px] lg:text-xs font-bold tracking-wider text-emerald-100 uppercase">
            Tôn Vinh Di Sản — Ghi Dấu Thời Đại (1968)
          </span>
        </div>

        {/* Quick View Toggle */}
        <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-full p-1 flex items-center text-[10px] sm:text-xs font-semibold text-white/70">
          <button
            type="button"
            onClick={() => setViewMode('heritage')}
            className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
              viewMode === 'heritage'
                ? 'bg-[#006a38] text-white font-bold shadow-sm'
                : 'hover:text-white'
            }`}
          >
            Di Sản Kiến Trúc
          </button>
          <button
            type="button"
            onClick={() => setViewMode('terraces')}
            className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
              viewMode === 'terraces'
                ? 'bg-[#006a38] text-white font-bold shadow-sm'
                : 'hover:text-white'
            }`}
          >
            Đồi Trà Bậc Thang
          </button>
          <button
            type="button"
            onClick={() => setViewMode('teahills')}
            className={`px-3 py-1 rounded-full transition-all cursor-pointer ${
              viewMode === 'teahills'
                ? 'bg-[#006a38] text-white font-bold shadow-sm'
                : 'hover:text-white'
            }`}
          >
            Cao Nguyên Bảo Lộc
          </button>
        </div>
      </div>

      {/* Subtle Scroll Hint */}
      <div className="hidden lg:flex absolute bottom-8 right-12 z-10 items-center gap-2 text-white/50 text-[11px] uppercase tracking-widest pointer-events-none">
        <span>Cuộn xuống để khám phá thực đơn</span>
        <div className="w-4 h-7 border border-white/30 rounded-full flex items-start justify-center p-1">
          <div className="w-1 h-1.5 bg-emerald-400 rounded-full animate-bounce" />
        </div>
      </div>
    </div>
  );
}
