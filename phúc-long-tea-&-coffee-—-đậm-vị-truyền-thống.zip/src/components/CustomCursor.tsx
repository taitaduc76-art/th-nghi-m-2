import { useEffect, useRef, useState } from 'react';

export function CustomCursor() {
  const cursorRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const leafRef = useRef<HTMLDivElement>(null);

  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isMouseDown, setIsMouseDown] = useState(false);

  // Position references for smooth lerp
  const mousePos = useRef({ x: -100, y: -100 });
  const ringPos = useRef({ x: -100, y: -100 });

  useEffect(() => {
    // Only active on desktop (>= 1024px) with mouse
    const isDesktop = window.matchMedia('(min-width: 1024px) and (pointer: fine)').matches;
    if (!isDesktop) return;

    document.body.classList.add('has-custom-cursor');

    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current.x = e.clientX;
      mousePos.current.y = e.clientY;
      setIsVisible(true);

      // Instantly position the center tea leaf for zero input lag
      if (leafRef.current) {
        leafRef.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`;
      }
    };

    const handleMouseDown = () => setIsMouseDown(true);
    const handleMouseUp = () => setIsMouseDown(false);

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      const isClickable = Boolean(
        target.closest(
          'button, a, input, select, textarea, [role="button"], .bp-card, .cell-slot, .cursor-pointer, label'
        )
      );
      setIsHovered(isClickable);
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    const handleMouseEnter = () => {
      setIsVisible(true);
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    document.addEventListener('mouseover', handleMouseOver, { passive: true });
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    // Smooth lerp loop for the outer floating circle
    let rafId: number;
    const animate = () => {
      const ease = 0.2;
      ringPos.current.x += (mousePos.current.x - ringPos.current.x) * ease;
      ringPos.current.y += (mousePos.current.y - ringPos.current.y) * ease;

      if (ringRef.current) {
        ringRef.current.style.transform = `translate3d(${ringPos.current.x}px, ${ringPos.current.y}px, 0)`;
      }

      rafId = requestAnimationFrame(animate);
    };

    rafId = requestAnimationFrame(animate);

    return () => {
      document.body.classList.remove('has-custom-cursor');
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      document.removeEventListener('mouseover', handleMouseOver);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div
      ref={cursorRef}
      id="custom-cursor-container"
      className="fixed inset-0 pointer-events-none z-[99999] hidden lg:block overflow-hidden"
      aria-hidden="true"
      style={{
        opacity: isVisible ? 1 : 0,
        transition: 'opacity 0.25s ease-out',
      }}
    >
      {/* 1. Outer Ethereal Trailing Ring */}
      <div
        ref={ringRef}
        className="fixed top-0 left-0 -translate-x-1/2 -translate-y-1/2 pointer-events-none will-change-transform"
      >
        <div
          className={`rounded-full transition-all duration-300 ease-out flex items-center justify-center ${
            isHovered
              ? 'w-14 h-14 border-2 border-[#34d399] bg-[#10b981]/15 shadow-[0_0_16px_rgba(52,211,153,0.5)]'
              : 'w-11 h-11 border-[1.5px] border-white/80 bg-black/10 backdrop-blur-[1px] shadow-[0_2px_10px_rgba(0,0,0,0.5)]'
          } ${isMouseDown ? 'scale-75' : isHovered ? 'scale-110' : 'scale-100'}`}
        />
      </div>

      {/* 2. Snappy Inner Tea Leaf Bud (Zero lag cursor head) */}
      <div
        ref={leafRef}
        className="fixed top-0 left-0 -translate-x-1/2 -translate-y-1/2 pointer-events-none will-change-transform"
      >
        <div
          className={`transition-transform duration-200 ease-out filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)] ${
            isHovered
              ? 'scale-125 rotate-12 text-[#4ade80]'
              : isMouseDown
              ? 'scale-85 -rotate-6 text-white'
              : 'scale-100 rotate-0 text-white'
          }`}
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
            className="w-6 h-6 transition-colors duration-200"
          >
            {/* Elegant stylized tea leaf bud */}
            <path
              d="M12 3 C16.5 7.5, 18.5 13, 14 18.5 C10.5 16, 7.5 12, 12 3 Z"
              fill="currentColor"
            />
            {/* Delicate leaf stem / spine */}
            <path
              d="M11 14 Q7 16 9 19.5"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              fill="none"
            />
            {/* Center spine ridge */}
            <path
              d="M12 6 C13 10, 13.5 13.5, 12.5 16"
              stroke={isHovered ? '#064e3b' : '#1e293b'}
              strokeWidth="0.8"
              strokeLinecap="round"
              fill="none"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
