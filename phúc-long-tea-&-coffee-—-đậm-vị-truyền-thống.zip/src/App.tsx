import { useEffect, useRef, useState, useMemo } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CustomCursor } from './components/CustomCursor';
import { PhucLongLogo } from './components/PhucLongLogo';
import { HeaderNav } from './components/HeaderNav';
import { ProductInfo } from './components/ProductInfo';
import { VideoCanvas } from './components/VideoCanvas';
import { GalleryPanel } from './components/GalleryPanel';
import { OutroOverlay } from './components/OutroOverlay';
import { DrinkDetailModal } from './components/DrinkDetailModal';
import { MenuOverviewModal } from './components/MenuOverviewModal';
import { StoryModal } from './components/StoryModal';
import { CartDrawer } from './components/CartDrawer';
import { buildLayout } from './utils/grid';
import { GALLERY_IMAGES, RANDOM_SYMBOLS, PHUCLONG_DRINKS } from './data';
import type { DrinkProduct, CartItem } from './types';

gsap.registerPlugin(ScrollTrigger);

function getResponsiveCols(): number {
  if (typeof window === 'undefined') return 4;
  if (window.innerWidth < 640) return 2;
  if (window.innerWidth < 1024) return 3;
  return 4;
}

export default function App() {
  const [cols, setCols] = useState<number>(4);
  const [videoVisible, setVideoVisible] = useState<boolean>(true);

  // Modals & Interactive State
  const [selectedDrink, setSelectedDrink] = useState<DrinkProduct | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isStoryOpen, setIsStoryOpen] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Current featured drink preview in bottom info
  const [activeDrinkIndex, setActiveDrinkIndex] = useState<number>(0);

  const spacerRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const innerWrapperRef = useRef<HTMLDivElement>(null);

  const lastScrollYRef = useRef<number>(0);
  const lastSymbolTimeRef = useRef<number>(0);
  const currentSymbolRef = useRef<string>('🍃');

  // Compute layout grid
  const layoutRows = useMemo(() => {
    return buildLayout(GALLERY_IMAGES.length, cols);
  }, [cols]);

  // Cart helper functions
  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex(
        (i) =>
          i.drink.id === newItem.drink.id &&
          i.sugar === newItem.sugar &&
          i.ice === newItem.ice &&
          i.topping === newItem.topping
      );
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += newItem.quantity;
        return updated;
      }
      return [...prev, newItem];
    });
  };

  const handleUpdateQuantity = (index: number, newQty: number) => {
    setCartItems((prev) => {
      const updated = [...prev];
      updated[index].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Scroll to top
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Handle responsiveness
  useEffect(() => {
    const handleResize = () => {
      setCols(getResponsiveCols());
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Main GSAP ScrollTrigger & RAF Scroll Engine
  useEffect(() => {
    const spacer = spacerRef.current;
    const panel = panelRef.current;
    const innerWrapper = innerWrapperRef.current;
    if (!spacer || !panel || !innerWrapper) return;

    let maxScroll = 0;

    const recalculateDimensions = () => {
      const vh = window.innerHeight;
      const wrapScrollHeight = innerWrapper.offsetHeight || innerWrapper.scrollHeight;
      maxScroll = Math.max(0, wrapScrollHeight - vh);
      const totalHeight = vh + maxScroll + 2 * vh;

      spacer.style.height = `${totalHeight}px`;
      ScrollTrigger.refresh();
    };

    recalculateDimensions();
    const resizeObserver = new ResizeObserver(() => {
      recalculateDimensions();
    });
    resizeObserver.observe(innerWrapper);

    window.addEventListener('resize', recalculateDimensions);

    const st = ScrollTrigger.create({
      trigger: spacer,
      start: 'top top',
      end: () => `+=${window.innerHeight}`,
      scrub: true,
    });

    const outroOverlay = document.getElementById('outro-overlay');
    const outroInfo = document.getElementById('outro-info');
    const outroBuy = document.getElementById('outro-buy');
    const outroFooter = document.getElementById('outro-footer');
    const symbolSpan = document.getElementById('circle-symbol');

    let rafId: number;

    const onFrame = () => {
      const scrollY = window.scrollY;
      const vh = window.innerHeight;
      const isDesktop = window.innerWidth >= 1024;
      const outroOffset = isDesktop ? 166 : 132;

      // Video visibility
      if (scrollY >= vh) {
        setVideoVisible(false);
      } else {
        setVideoVisible(true);
      }

      // Phase 1 (0 to vh): Black panel slides up
      // Phase 2 (scrollY > vh): Panel fixed at top, inner wrapper translates up
      if (scrollY <= vh) {
        const panelY = vh - scrollY;
        panel.style.transform = `translateY(${panelY}px)`;
        innerWrapper.style.transform = 'translateY(0px)';
      } else {
        panel.style.transform = 'translateY(0px)';
        const wrapY = -(scrollY - vh);
        innerWrapper.style.transform = `translateY(${wrapY}px)`;
      }

      // Card Scaling Calculation (per-frame in RAF)
      const slots = innerWrapper.querySelectorAll('.cell-slot');
      slots.forEach((slotNode) => {
        const slot = slotNode as HTMLDivElement;
        const card = slot.querySelector('.bp-card') as HTMLDivElement | null;
        if (!card) return;

        const rect = slot.getBoundingClientRect();
        const top = rect.top;
        const bottom = rect.bottom;

        if (bottom <= 0 || top >= vh) {
          card.style.transform = 'scale(0)';
        } else {
          const enter = Math.min(1, (vh - top) / (vh * 0.6));
          const exit = Math.min(1, bottom / (vh * 0.4));
          const finalScale = Math.max(0, Math.min(1, Math.min(enter, exit)));
          card.style.transform = `scale(${finalScale})`;
        }
      });

      // Outro Phase (scrollY > vh + maxScroll)
      if (scrollY > vh + maxScroll) {
        const denom = Math.max(1, vh - 100);
        const outroProgress = Math.max(0, Math.min(1, (scrollY - vh - maxScroll) / denom));

        if (outroOverlay) {
          outroOverlay.style.opacity = String(outroProgress);
        }
        if (outroInfo) {
          outroInfo.style.transform = `translateY(${-outroProgress * outroOffset}px)`;
        }
        if (outroBuy) {
          outroBuy.style.transform = `scale(${outroProgress})`;
        }
        if (outroFooter) {
          outroFooter.style.opacity = String(outroProgress);
        }
      } else {
        if (outroOverlay) outroOverlay.style.opacity = '0';
        if (outroInfo) outroInfo.style.transform = 'translateY(0px)';
        if (outroBuy) outroBuy.style.transform = 'scale(0)';
        if (outroFooter) outroFooter.style.opacity = '0';
      }

      // Dynamic symbol and featured beverage cycler on scroll
      if (Math.abs(scrollY - lastScrollYRef.current) > 1) {
        const now = performance.now();
        if (now - lastSymbolTimeRef.current > 120) {
          lastSymbolTimeRef.current = now;
          const remainingSymbols = RANDOM_SYMBOLS.filter(
            (s) => s !== currentSymbolRef.current
          );
          const nextSymbol =
            remainingSymbols[Math.floor(Math.random() * remainingSymbols.length)];
          currentSymbolRef.current = nextSymbol;
          if (symbolSpan) {
            symbolSpan.textContent = nextSymbol;
          }

          // Cycle current featured drink
          const drinkIdx = Math.floor((scrollY / (vh * 0.8))) % PHUCLONG_DRINKS.length;
          setActiveDrinkIndex(drinkIdx);
        }
      }
      lastScrollYRef.current = scrollY;

      rafId = requestAnimationFrame(onFrame);
    };

    rafId = requestAnimationFrame(onFrame);

    return () => {
      cancelAnimationFrame(rafId);
      resizeObserver.disconnect();
      window.removeEventListener('resize', recalculateDimensions);
      st.kill();
    };
  }, [cols, layoutRows]);

  const featuredDrink = PHUCLONG_DRINKS[activeDrinkIndex] || PHUCLONG_DRINKS[0];
  const totalCartCount = cartItems.reduce((acc, i) => acc + i.quantity, 0);

  return (
    <div
      ref={spacerRef}
      id="scroll-spacer"
      className="relative select-none bg-[#091710] min-h-screen lg:cursor-none w-full"
      style={{ height: '500vh' }}
    >
      {/* 1A. Custom Cursor (Desktop only) */}
      <CustomCursor />

      {/* 1B. Logo (Top Left) - Phuc Long Brand Badge */}
      <PhucLongLogo onHomeClick={handleScrollToTop} />

      {/* 1D. Header Navigation (Top Right) */}
      <HeaderNav
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenStory={() => setIsStoryOpen(true)}
      />

      {/* 1E. Product Info (Bottom Right) */}
      <ProductInfo
        currentSymbol={currentSymbolRef.current}
        selectedDrinkName={featuredDrink.name}
        selectedDrinkPrice={featuredDrink.formattedPrice}
      />

      {/* 1G & 1H. Hero Video & Landscape Background */}
      <VideoCanvas isVisible={videoVisible} />

      {/* SECTION 2: Phuc Long Beverage Gallery Panel */}
      <GalleryPanel
        ref={panelRef}
        cols={cols}
        layoutRows={layoutRows}
        innerWrapperRef={innerWrapperRef}
        onSelectDrink={(drink) => setSelectedDrink(drink)}
      />

      {/* 1F, 1I, 1J. Outro Overlay, Menu Button & Footer */}
      <OutroOverlay onExploreClick={() => setIsMenuOpen(true)} />

      {/* INTERACTIVE MODALS & DRAWERS */}
      {/* Drink Customization & Detail Modal */}
      <DrinkDetailModal
        drink={selectedDrink}
        onClose={() => setSelectedDrink(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Full Drink Catalog / Menu Modal */}
      <MenuOverviewModal
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onSelectDrink={(drink) => setSelectedDrink(drink)}
      />

      {/* Phuc Long 1968 Heritage Story Modal */}
      <StoryModal
        isOpen={isStoryOpen}
        onClose={() => setIsStoryOpen(false)}
        onExploreMenu={() => setIsMenuOpen(true)}
      />

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}
